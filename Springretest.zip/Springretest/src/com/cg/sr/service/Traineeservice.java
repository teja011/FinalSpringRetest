package com.cg.sr.service;

import java.util.List;

import com.cg.sr.bean.TraineeBean;

public interface Traineeservice {
	
	public TraineeBean addTrainee(TraineeBean traineebean);
	public TraineeBean findTrainee(int traineeid);
	List<TraineeBean> gettraineeList();
	public void deleteTrainee(int traineeid);
	public void updateTrainee(TraineeBean traineebean);

}
