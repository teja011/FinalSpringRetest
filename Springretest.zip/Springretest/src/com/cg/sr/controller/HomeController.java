package com.cg.sr.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.sr.bean.TraineeBean;
import com.cg.sr.service.Traineeservice;

@Controller
public class HomeController {
	@Autowired
	Traineeservice tser;
	
	
	
	public Traineeservice getTser() {
		return tser;
	}
	public void setTser(Traineeservice tser) {
		this.tser = tser;
	}
	
	
	
	@RequestMapping("login")
	public String validateUser(Model model ,
			  @RequestParam("username") String uname,
			  @RequestParam("password")String pass){
		if(uname.equals("tejas") && pass.equals("tejas"))
		{
		model.addAttribute("successMsg",
				"Trainee Management System");
		model.addAttribute("username", uname);
		return "Home";
		}
		else
		{
			model.addAttribute
			("errorMsg", "Invalid Username/Password");
			return "Error";
		}
	}
@RequestMapping("addtrainee")
public String insertTRainee(Model model)
{
TraineeBean traineebean = new TraineeBean();	
model.addAttribute("traineeBean", traineebean);
	return "insertT";
}

@RequestMapping("inserttrainee")
public String addt(Model model, @ModelAttribute("traineeBean")@Valid TraineeBean traineebean,BindingResult result)
{
	
	traineebean = tser.addTrainee(traineebean);
	model.addAttribute("traineebean",traineebean);
	model.addAttribute("SuccessMsg","Trainee Added");
	return "Success";
}

@RequestMapping("searchtrainee")
public String searchT(Model model)
{
 TraineeBean traineebean= new TraineeBean();
	model.addAttribute("traineeBean", traineebean);
return "searchTrainee";
}

@RequestMapping("strainee")
public String strainee(Model model,@RequestParam("traineeid") String tid ){
	
	int a = Integer.parseInt(tid);
	TraineeBean traineebean=tser.findTrainee(a);
	if(traineebean==null)
	{
		return "Error";
	}
	
	
	model.addAttribute("traineebean", traineebean);
	model.addAttribute("successMsg", "Student Added ");
	return "fsuccess";
	
	
}

@RequestMapping("getallTrainee")
public String getallTrainee(Model model)
{
	TraineeBean traineebean = new TraineeBean();
	List<TraineeBean> cclist = tser.gettraineeList();
	model.addAttribute("cclist", cclist);
	model.addAttribute("traineebean", traineebean);
	
	
return "showall";
	}

@RequestMapping("deletetraineee")
public String delett(Model model)
{
	TraineeBean traineebean= new TraineeBean();
	model.addAttribute("traineeBean", traineebean);
	return "deleteTrainee";
}


@RequestMapping("deletetrainee")
public String deleteStudent(@RequestParam("traineeid") int sid){
	tser.deleteTrainee(sid);
	return "dsuccess";
}




@RequestMapping("updateTTrainee")
public String updateStudent(Model model){

	TraineeBean traineebean= new TraineeBean();
	model.addAttribute("traineeBean", traineebean);
	return "up";
	}

@RequestMapping("uppp")

public String updateStudentAction(Model model , @ModelAttribute("traineeBean") TraineeBean traineebean){
	/*tser.updateTrainee(traineebean);*/
	/*model.addAttribute("traineeBean", traineebean);*/
	/*int a = Integer.parseInt(tid);*/
	TraineeBean traineebeann =tser.findTrainee(traineebean.getTraineeid());
	model.addAttribute("traineebeann", traineebeann);
	
return "UpdateTrainee";
}

@RequestMapping("updatttrainee")
public String fgh(Model model, @ModelAttribute("traineebeann")@Valid TraineeBean traineebean,BindingResult result)
{
	tser.updateTrainee(traineebean);
	
	
	return "qwer";
	
}

}